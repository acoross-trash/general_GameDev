﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MysticLabyrinth_alpha_1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
            panel1.Visible = false;
            panel2.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CBattleSeq cui1 = new CBattleSeq();
            cui1.Run();

            CUIBattleManager cui = new CUIBattleManager();
            cui.Run();
        }

        #region GUI_version
        BattleCharacter[] m_PCs;
        int m_nPCNum;

        BattleCharacter[] m_Enemys;
        int m_nEnemyNum;

        BattleCharacter[] m_AllChars;
        int m_nCharNum;

        // 수행할 커맨드
        Command[] m_CmdList;

        // 행동 우선순위 리스트
        int[] m_InitiList;

        private void btGUIStart_Click(object sender, EventArgs e)
        {
            InitBattle();
        }

        public void InitBattle()
        {
            // 전장 초기화
            m_nPCNum = 3;
            m_PCs = new BattleCharacter[m_nPCNum];
            for (int i = 0; i < m_nPCNum; ++i)
            {
                BattleCharacter tmp = new BattleCharacter();
                tmp.MaxHP = 100;
                tmp.HP = 100;
                m_PCs[i] = tmp;
            }
            m_PCs[0].Name = "Warrior";
            m_PCs[1].Name = "Magician";
            m_PCs[2].Name = "Cleric";

            m_nEnemyNum = 3;
            m_Enemys = new BattleCharacter[m_nEnemyNum];
            for (int i = 0; i < m_nEnemyNum; ++i)
            {
                BattleCharacter tmp = new BattleCharacter();
                tmp.Name = "Enemy" + i.ToString();
                tmp.MaxHP = 100;
                tmp.HP = 100;
                m_Enemys[i] = tmp;
            }

            m_nCharNum = m_nPCNum + m_nEnemyNum;
            m_AllChars = new BattleCharacter[m_nCharNum];
            for (int i = 0; i < m_nPCNum; ++i)
                m_AllChars[i] = m_PCs[i];
            for (int i = 0; i < m_nEnemyNum; ++i)
                m_AllChars[m_nPCNum + i] = m_Enemys[i];

            // 전투 시작 메시지
            Console.WriteLine("Battle Start!");

            // 커맨드 입력 대기 상태로.
            bGetCmdMode = true;
            m_CmdList = new Command[m_nCharNum];
            panel1.Visible = true;
            m_nCmdInputState = 0;

            // 첫번째 캐릭터의 커맨드 입력을 받는다.
            label1.Text = m_PCs[m_nCmdInputState].Name;
        }

        int m_nCmdInputState = 0;
        int m_nSelectedCommand = -1;

        bool bGetCmdMode;

        // UI 코드
        private void ShowTargetSelectWindow()
        {
            panel2.Visible = true;
            label2.Text = m_PCs[m_nCmdInputState].Name;

            BattleCharacter[] targets;
            targets = m_AllChars;

            foreach (BattleCharacter target in targets)
            {
                listBox1.Items.Add(target.Name);
            }
        }
        
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            panel2.Visible = false;
            label2.Text = "";

            int targetIdx = listBox1.SelectedIndex;

            listBox1.Items.Clear();

            SetCommand(m_nCmdInputState, m_nSelectedCommand, targetIdx);

            m_nCmdInputState++;
            if (m_nCmdInputState >= m_nPCNum)
            {
                // 명령 수행 상태로.
                bGetCmdMode = false;

                MakeInitiList();

                MakeEnemiesCommands();

                int nFinishType = -1;
                bool bFinished = true;
                CUIExecBattleCommands(out nFinishType, out bFinished);

                if (bFinished)
                {
                    // 종료 처리
                    CloseBattle(nFinishType);
                }
                else
                {
                    // 다시 cmd 받기로.
                    bGetCmdMode = true;
                    m_nCmdInputState = 0;
                    label1.Text = m_PCs[m_nCmdInputState].Name;
                }
            }
            else
            {
                // 다음 캐릭터 cmd 받기.
                label1.Text = m_PCs[m_nCmdInputState].Name;
            }
        }
        // UI 코드 end

        void MakeEnemiesCommands()
        {
            // 적군의 명령을 생성한다.
            for (int i = 0; i < m_nEnemyNum; ++i)
            {
                Skill tmpCmd = new Skill();
                tmpCmd.actor = m_Enemys[i];
                tmpCmd.target = m_PCs[i];
                tmpCmd.skillID = 0; // 가만히 있기
                m_CmdList[m_nPCNum + i] = tmpCmd;
            }
        }

        public void CloseBattle(int nFinishType)
        {
            panel1.Visible = false;
            switch (nFinishType)
            {
                case 0: // 적 전멸
                    Console.WriteLine("You defeated all enemies.\nBattle ends.");
                    break;
                case 1: // 아군 전멸
                    Console.WriteLine("You all died.\nBattle ends.");
                    break;
                case 2: // 도망 성공
                    Console.WriteLine("You escaped from battle.\nBattle ends.");
                    break;
                case 3: // 이벤트
                    Console.WriteLine("Battle ends by event.");
                    break;
                default: // 에러
                    System.Diagnostics.Debug.Assert(false, "FinishType error.");
                    Console.WriteLine("Battle ends. Finish Type error.");
                    break;
            }
        }
        private void CUIExecBattleCommands(out int nFinishType, out bool bFinished)
        {
            // 우선권에 따라 명령을 수행한다.
            bFinished = false;
            nFinishType = -1;
            foreach (int i in m_InitiList)
            {
                Command cmd = m_CmdList[i];
                if (cmd.actor.IsAlive())
                {
                    cmd.Run();

                    CheckBattleEnd(out nFinishType, out bFinished, cmd);

                    if (bFinished)
                        break;
                }
            }
        }

        private void CheckBattleEnd(out int nFinishType, out bool bFinished, Command cmd)
        {
            // 아군 전멸?
            bFinished = false;
            nFinishType = -1;
            bool bAllDead = true;
            foreach (BattleCharacter pc in m_PCs)
            {
                if (pc.IsAlive())
                {
                    bAllDead = false;
                    break;
                }
            }
            if (bAllDead)
            {
                nFinishType = 1;
                bFinished = true;
            }
            else
            {
                // 적군 전멸?
                bAllDead = true;
                foreach (BattleCharacter enemy in m_Enemys)
                {
                    if (enemy.IsAlive())
                    {
                        bAllDead = false;
                        break;
                    }
                }
                if (bAllDead)
                {
                    nFinishType = 0;
                    bFinished = true;
                }

                // 도망 성공?
                // todo
            }
        }

        private void SetCommand(int _i, int cmd, int targetIdx)
        {
            BattleCharacter PC = m_PCs[_i];
            switch (cmd)
            {
                case 0:
                    {
                        Attack tmpCmd = new Attack();
                        tmpCmd.actor = PC;
                        tmpCmd.target = m_AllChars[targetIdx];
                        m_CmdList[_i] = tmpCmd;
                        break;
                    }
                default:
                    {
                        Skill tmpCmd = new Skill();
                        tmpCmd.actor = PC;
                        tmpCmd.target = PC;
                        tmpCmd.skillID = 0; // 가만히 있기
                        m_CmdList[_i] = tmpCmd;
                        break;
                    }
            }
        }

        private void btSkill_Click(object sender, EventArgs e)
        {
            if (bGetCmdMode)
            {
                m_nSelectedCommand = 1;
                ShowTargetSelectWindow();
            }
        }

        private void btAttack_Click(object sender, EventArgs e)
        {
            if (bGetCmdMode)
            {
                m_nSelectedCommand = 0;
                ShowTargetSelectWindow();
            }
        }

        // 우선권 처리
        // 우선권을 계산한다.
        void MakeInitiList()
        {
            m_InitiList = new int[m_nCharNum];
            for (int i = 0; i < m_nCharNum; ++i)
            {
                m_InitiList[i] = i;
            }
        }
        #endregion GUI_version
    }
}
