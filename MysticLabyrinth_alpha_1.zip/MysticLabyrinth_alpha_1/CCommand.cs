﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MysticLabyrinth_alpha_1
{
    abstract class Command
    {
        public BattleCharacter actor;

        public abstract void Run();
    }

    class Attack : Command
    {
        public BattleCharacter target;

        public override void Run()
        {
            // 공격자 요소: 힘, 무기공격력, 무기타입, 속성
            // 피공격자 요소: 체력, 방어구의 공격타입별방어력, 속성내성

            //gara
            int nDamage = 100;
            target.ReduceHP(nDamage);
            Console.WriteLine("{0}이(가) {1}을(를) 공격했다!", actor.Name, target.Name);
            Console.WriteLine("{0}은(는) {1}의 데미지를 입었다!", target.Name, nDamage);

            if (target.IsDead())
            {
                Console.WriteLine("{0}은(는) 죽었다.", target.Name);
            }
        }
    }

    class Defend : Command
    {
        public override void Run()
        {
            throw new NotImplementedException();
        }
    }

    class Skill : Command
    {
        public BattleCharacter target;
        public int skillID;
        public override void Run()
        {
            Console.WriteLine("{0}은(는) 가만히 상황을 지켜보고 있다.", actor.Name);
        }
    }

    class Item : Command
    {
        public BattleCharacter target;
        public int itemID;
        public override void Run()
        {
            throw new NotImplementedException();
        }
    }

    class Escape : Command
    {
        public override void Run()
        {
            throw new NotImplementedException();
        }
    }
}
