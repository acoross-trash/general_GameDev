﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MysticLabyrinth_alpha_1
{
    class GUIBattleManager
    {
        CBattle m_battle;
        Form1 m_WinForm;

        public GUIBattleManager(Form1 form)
        {
            m_WinForm = form;
            m_battle = new CBattle();
        }

        public void InitBattle()
        {
            m_battle.InitBattle();

            m_battle.SetCommandState(0);

            
        }

        // command 를 얻기 위한 UI를 설정한다.
        // command 변경은 해당 UI에 의해 이루어진다.
        // m_battle.SetCommand(...); 를 통해 command를 설정.

        public void SetCommand(int num)
        {

        }

        public void ExecBattleCommands()
        {
            // 전투 루프
            // 종료타입 nFinishType: 0. 적 전멸 1. 아군 전멸 2. 도망 성공 3. 이벤트
            int nFinishType = -1;
            bool bFinished = false;
            {
                //command: 0.공격, 1.스킬, 2.방어, 3.도망, 4.아이템
                m_battle.InitCommandList();

                // 아군의 할 일을 얻어낸다.
                m_battle.CUIGetPCCommands();

                // 적군의 할 일을 생성.
                m_battle.MakeEnemyCommands();

                // 선처리 명령을 수행한다.
                // TODO

                // 우선권을 계산한다.
                m_battle.MakeInitiList();

                m_battle.CUIExecBattleCommands(ref nFinishType, ref bFinished);
            }

            if (bFinished)
            {
                CBattle.CloseBattle(nFinishType);
            }
            else
            {
                // 
            }
        }
    }
}
